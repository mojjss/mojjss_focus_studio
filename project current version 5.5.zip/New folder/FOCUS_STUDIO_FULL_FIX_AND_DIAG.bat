@echo off
setlocal EnableExtensions
set "SELF=%~f0"
set "ORIGINAL_DIR=%CD%"
title Mojjss Focus Studio - Full Fix and Diagnostics

fltmc >nul 2>&1
if errorlevel 1 (
  echo Requesting Administrator permission...
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath $env:SELF -Verb RunAs -WorkingDirectory (Split-Path -LiteralPath $env:SELF)"
  exit /b
)

set "TEMP_PS1=%TEMP%\MojjssFocusStudioDiag_%RANDOM%_%RANDOM%.ps1"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$lines=Get-Content -LiteralPath $env:SELF; $i=[Array]::IndexOf($lines,'#PS1_BEGIN'); if($i -lt 0){exit 2}; $lines[($i+1)..($lines.Count-1)] | Set-Content -LiteralPath $env:TEMP_PS1 -Encoding UTF8"
if errorlevel 1 (
  echo Could not extract the embedded diagnostic engine.
  pause
  exit /b 2
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%TEMP_PS1%" -BatPath "%SELF%" -OriginalDir "%ORIGINAL_DIR%"
set "RC=%ERRORLEVEL%"
del /q "%TEMP_PS1%" >nul 2>&1
echo.
if not "%RC%"=="0" echo The tool finished with code %RC%. Read 00_SUMMARY.txt in the report ZIP.
pause
exit /b %RC%

#PS1_BEGIN
param(
    [string]$BatPath,
    [string]$OriginalDir
)

$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

function Protect-Text {
    param([AllowNull()][object]$Text)
    if ($null -eq $Text) { return '' }
    $s = [string]$Text
    $s = [regex]::Replace($s, 'eyJ[A-Za-z0-9._~-]{20,}', '<REDACTED_TUNNEL_TOKEN>')
    $s = [regex]::Replace($s, '(?i)(--token\s+)([^\s"'']+)', '$1<REDACTED_TUNNEL_TOKEN>')
    $s = [regex]::Replace($s, '(?i)(service\s+install\s+)([^\s"'']+)', '$1<REDACTED_TUNNEL_TOKEN>')
    $s = [regex]::Replace($s, '(?i)([?&](?:token|key|password|secret|auth)=)[^&\s]+', '$1<REDACTED>')
    $s = [regex]::Replace($s, '(?im)^([ \t]*"?(?:token|password|secret|viewer_key|owner_key|desktop_write_key|cloud_desktop_write_key|pixela_token)"?[ \t]*[:=][ \t]*).+$', '$1<REDACTED>')
    $s = [regex]::Replace($s, '(?i)(Authorization:\s*(?:Bearer|Basic)\s+)[^\s]+', '$1<REDACTED>')
    $s = [regex]::Replace($s, '(?i)gh[pousr]_[A-Za-z0-9]{20,}', '<REDACTED_GITHUB_TOKEN>')
    $s = [regex]::Replace($s, '(?i)(https?://)[^/@\s:]+:[^/@\s]+@', '$1<REDACTED>@')
    return $s
}

function Add-ReportLine {
    param([string]$File, [AllowNull()][object]$Text = '')
    $safe = Protect-Text $Text
    Add-Content -LiteralPath $File -Value $safe -Encoding UTF8
}

function Add-Section {
    param([string]$File, [string]$Title)
    Add-ReportLine $File ''
    Add-ReportLine $File ('=' * 84)
    Add-ReportLine $File $Title
    Add-ReportLine $File ('=' * 84)
}

function Capture-Block {
    param(
        [string]$File,
        [string]$Title,
        [scriptblock]$Block
    )
    Add-Section $File $Title
    try {
        $output = & $Block 2>&1 | Out-String -Width 260
        Add-ReportLine $File $output.TrimEnd()
    } catch {
        Add-ReportLine $File ("ERROR: " + $_.Exception.GetType().Name + ': ' + $_.Exception.Message)
    }
}

function Add-Summary {
    param([string]$Level, [string]$Message)
    $line = ('[{0}] {1}' -f $Level.ToUpperInvariant(), $Message)
    Add-ReportLine $script:SummaryFile $line
    Write-Host $line
}

function Find-ProjectRoot {
    $batDir = Split-Path -Parent $BatPath
    $candidates = New-Object System.Collections.Generic.List[string]
    foreach ($candidate in @(
        $env:FOCUS_STUDIO_HOME,
        $batDir,
        (Split-Path -Parent $batDir),
        $OriginalDir,
        'D:\my_projects\mojjss_focus_studio',
        'C:\my_projects\mojjss_focus_studio',
        (Join-Path $env:USERPROFILE 'Desktop\mojjss_focus_studio'),
        (Join-Path $env:USERPROFILE 'Documents\mojjss_focus_studio')
    )) {
        if ($candidate -and -not $candidates.Contains($candidate)) { [void]$candidates.Add($candidate) }
    }

    foreach ($candidate in $candidates) {
        try {
            $resolved = (Resolve-Path -LiteralPath $candidate -ErrorAction Stop).Path
            if (Test-Path -LiteralPath (Join-Path $resolved 'desktop_app\app.py')) { return $resolved }
            if ((Split-Path -Leaf $resolved) -eq 'desktop_app' -and (Test-Path -LiteralPath (Join-Path $resolved 'app.py'))) {
                return (Split-Path -Parent $resolved)
            }
        } catch {}
    }

    Write-Host ''
    Write-Host 'Focus Studio project folder was not found automatically.' -ForegroundColor Yellow
    $entered = Read-Host 'Paste the project folder path (the folder containing desktop_app) or press Enter to continue without it'
    $entered = $entered.Trim('"')
    if ($entered -and (Test-Path -LiteralPath (Join-Path $entered 'desktop_app\app.py'))) {
        return (Resolve-Path -LiteralPath $entered).Path
    }
    return $null
}

function Get-CloudflaredPath {
    $paths = New-Object System.Collections.Generic.List[string]
    try {
        $svc = Get-CimInstance Win32_Service -Filter "Name='Cloudflared'" -ErrorAction Stop
        if ($svc.PathName) {
            $m = [regex]::Match($svc.PathName, '^\s*"([^"]+cloudflared\.exe)"|^\s*([^\s]+cloudflared\.exe)', 'IgnoreCase')
            if ($m.Success) {
                $p = if ($m.Groups[1].Value) { $m.Groups[1].Value } else { $m.Groups[2].Value }
                if ($p) { [void]$paths.Add($p) }
            }
        }
    } catch {}
    try {
        $cmd = Get-Command cloudflared.exe -ErrorAction Stop
        if ($cmd.Source) { [void]$paths.Add($cmd.Source) }
    } catch {}
    foreach ($p in @(
        'C:\Program Files\cloudflared\cloudflared.exe',
        'C:\Program Files (x86)\cloudflared\cloudflared.exe',
        'C:\Cloudflared\bin\cloudflared.exe',
        'C:\Windows\System32\cloudflared.exe',
        (Join-Path $env:USERPROFILE 'cloudflared.exe')
    )) { [void]$paths.Add($p) }
    foreach ($p in ($paths | Select-Object -Unique)) {
        if ($p -and (Test-Path -LiteralPath $p)) { return (Resolve-Path -LiteralPath $p).Path }
    }
    return $null
}

function Get-PythonInfo {
    param([string]$ProjectRoot)
    $result = [ordered]@{ Exe = $null; Prefix = @(); PythonW = $null }
    if ($ProjectRoot) {
        $venvPy = Join-Path $ProjectRoot 'desktop_app\.venv\Scripts\python.exe'
        $venvPyW = Join-Path $ProjectRoot 'desktop_app\.venv\Scripts\pythonw.exe'
        if (Test-Path -LiteralPath $venvPy) {
            $result.Exe = $venvPy
            if (Test-Path -LiteralPath $venvPyW) { $result.PythonW = $venvPyW }
            return [pscustomobject]$result
        }
        $rootVenvPy = Join-Path $ProjectRoot '.venv\Scripts\python.exe'
        $rootVenvPyW = Join-Path $ProjectRoot '.venv\Scripts\pythonw.exe'
        if (Test-Path -LiteralPath $rootVenvPy) {
            $result.Exe = $rootVenvPy
            if (Test-Path -LiteralPath $rootVenvPyW) { $result.PythonW = $rootVenvPyW }
            return [pscustomobject]$result
        }
    }
    try {
        $py = Get-Command py.exe -ErrorAction Stop
        $result.Exe = $py.Source
        & $py.Source -3.11 -c 'import sys' *> $null
        if ($LASTEXITCODE -eq 0) { $result.Prefix = @('-3.11') } else { $result.Prefix = @() }
        return [pscustomobject]$result
    } catch {}
    try {
        $python = Get-Command python.exe -ErrorAction Stop
        $result.Exe = $python.Source
        $pythonw = Join-Path (Split-Path -Parent $python.Source) 'pythonw.exe'
        if (Test-Path -LiteralPath $pythonw) { $result.PythonW = $pythonw }
        return [pscustomobject]$result
    } catch {}
    return [pscustomobject]$result
}

function Invoke-Python {
    param(
        [pscustomobject]$PythonInfo,
        [string[]]$Arguments
    )
    if (-not $PythonInfo.Exe) { throw 'Python was not found.' }
    $allArgs = @($PythonInfo.Prefix) + @($Arguments)
    & $PythonInfo.Exe @allArgs 2>&1
}

function Invoke-HttpCheck {
    param(
        [string]$Url,
        [ValidateSet('GET','POST','OPTIONS','HEAD')][string]$Method = 'GET',
        [hashtable]$Headers = @{},
        [switch]$NoProxy,
        [int]$TimeoutSeconds = 15
    )
    $status = 0
    $body = ''
    $responseHeaders = @{}
    $errorText = ''
    try {
        $request = [System.Net.HttpWebRequest]::Create($Url)
        $request.Method = $Method
        $request.Timeout = $TimeoutSeconds * 1000
        $request.ReadWriteTimeout = $TimeoutSeconds * 1000
        $request.AllowAutoRedirect = $true
        $request.UserAgent = 'MojjssFocusStudioDiagnostic/1.0'
        if ($NoProxy) { $request.Proxy = $null }
        foreach ($key in $Headers.Keys) {
            switch -Regex ($key) {
                '^User-Agent$' { $request.UserAgent = [string]$Headers[$key]; continue }
                '^Accept$' { $request.Accept = [string]$Headers[$key]; continue }
                '^Content-Type$' { $request.ContentType = [string]$Headers[$key]; continue }
                default { $request.Headers[$key] = [string]$Headers[$key] }
            }
        }
        if ($Method -in @('POST','OPTIONS')) { $request.ContentLength = 0 }
        $response = [System.Net.HttpWebResponse]$request.GetResponse()
        $status = [int]$response.StatusCode
        foreach ($key in $response.Headers.AllKeys) { $responseHeaders[$key] = $response.Headers[$key] }
        if ($Method -ne 'HEAD') {
            $reader = New-Object System.IO.StreamReader($response.GetResponseStream())
            $body = $reader.ReadToEnd()
            $reader.Dispose()
        }
        $response.Dispose()
    } catch [System.Net.WebException] {
        $errorText = $_.Exception.Message
        if ($_.Exception.Response) {
            $response = [System.Net.HttpWebResponse]$_.Exception.Response
            $status = [int]$response.StatusCode
            foreach ($key in $response.Headers.AllKeys) { $responseHeaders[$key] = $response.Headers[$key] }
            try {
                $reader = New-Object System.IO.StreamReader($response.GetResponseStream())
                $body = $reader.ReadToEnd()
                $reader.Dispose()
            } catch {}
            $response.Dispose()
        }
    } catch {
        $errorText = $_.Exception.Message
    }
    return [pscustomobject]@{
        Url = $Url
        Status = $status
        Body = Protect-Text $body
        Headers = $responseHeaders
        Error = Protect-Text $errorText
    }
}

function Format-HttpResult {
    param([pscustomobject]$Result, [int]$BodyLimit = 1800)
    $lines = New-Object System.Collections.Generic.List[string]
    [void]$lines.Add("URL: $($Result.Url)")
    [void]$lines.Add("HTTP: $($Result.Status)")
    if ($Result.Error) { [void]$lines.Add("Error: $($Result.Error)") }
    foreach ($name in @('Server','Content-Type','CF-RAY','Access-Control-Allow-Origin','Location')) {
        if ($Result.Headers.ContainsKey($name)) { [void]$lines.Add("$name`: $($Result.Headers[$name])") }
    }
    if ($Result.Body) {
        $preview = $Result.Body
        if ($preview.Length -gt $BodyLimit) { $preview = $preview.Substring(0,$BodyLimit) + "`n<TRUNCATED>" }
        [void]$lines.Add('Body preview:')
        [void]$lines.Add($preview)
    }
    return ($lines -join "`r`n")
}

function Get-SourceVersion {
    param([string]$ProjectRoot)
    if (-not $ProjectRoot) { return '' }
    $versionFile = Join-Path $ProjectRoot 'desktop_app\version.py'
    if (-not (Test-Path -LiteralPath $versionFile)) { return '' }
    $text = Get-Content -LiteralPath $versionFile -Raw -ErrorAction SilentlyContinue
    $m = [regex]::Match($text, 'APP_VERSION\s*=\s*["'']([^"'']+)["'']')
    if ($m.Success) { return $m.Groups[1].Value }
    return ''
}

function Get-ConfigSummary {
    param([string]$ConfigPath)
    if (-not (Test-Path -LiteralPath $ConfigPath)) { return 'config.json does not exist.' }
    try {
        $c = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json
        $safe = [ordered]@{
            timezone = $c.timezone
            monitor_enabled = $c.monitor_enabled
            monitor_port = $c.monitor_port
            cloud_dashboard_enabled = $c.cloud_dashboard_enabled
            cloud_dashboard_url = $c.cloud_dashboard_url
            cloud_two_way_sync_enabled = $c.cloud_two_way_sync_enabled
            remote_camera_enabled = $c.remote_camera_enabled
            remote_camera_index = $c.remote_camera_index
            remote_camera_width = $c.remote_camera_width
            remote_camera_height = $c.remote_camera_height
            remote_camera_fps = $c.remote_camera_fps
            tailscale_camera_port = $c.tailscale_camera_port
            tailscale_camera_url = $c.tailscale_camera_url
            tailscale_camera_allowed_origin = $c.tailscale_camera_allowed_origin
            tailscale_camera_require_identity = $c.tailscale_camera_require_identity
            camera_password_configured = [bool]($c.remote_camera_password_hash -and $c.remote_camera_password_salt)
            desktop_write_key_configured = [bool]$c.cloud_desktop_write_key
            pixela_token_configured = [bool]$c.token
        }
        return ($safe | ConvertTo-Json -Depth 5)
    } catch {
        return "config.json is invalid: $($_.Exception.Message)"
    }
}

function Get-ConfigObject {
    param([string]$ProjectRoot)
    if (-not $ProjectRoot) { return $null }
    $path = Join-Path $ProjectRoot 'desktop_app\config.json'
    if (-not (Test-Path -LiteralPath $path)) { return $null }
    try { return (Get-Content -LiteralPath $path -Raw | ConvertFrom-Json) } catch { return $null }
}

function Get-PortOwners {
    param([int[]]$Ports)
    $rows = @()
    foreach ($port in $Ports) {
        $connections = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
        foreach ($connection in $connections) {
            $proc = Get-CimInstance Win32_Process -Filter "ProcessId=$($connection.OwningProcess)" -ErrorAction SilentlyContinue
            $rows += [pscustomobject]@{
                Port = $port
                Address = $connection.LocalAddress
                PID = $connection.OwningProcess
                Process = $proc.Name
                ExecutablePath = $proc.ExecutablePath
                CommandLine = Protect-Text $proc.CommandLine
            }
        }
    }
    return $rows
}

function Ensure-FirewallRule {
    param([string]$Name, [string]$Program)
    if (-not $Program -or -not (Test-Path -LiteralPath $Program)) { return }
    try {
        Get-NetFirewallRule -DisplayName $Name -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
        New-NetFirewallRule -DisplayName $Name -Direction Outbound -Program $Program -Action Allow -Profile Any -Description 'Created by Mojjss Focus Studio repair tool' | Out-Null
        Add-ReportLine $script:RepairFile "Created outbound firewall rule: $Name -> $Program"
    } catch {
        Add-ReportLine $script:RepairFile "Firewall rule failed: $Name : $($_.Exception.Message)"
    }
}

function Start-CorrectFocusStudio {
    param([string]$ProjectRoot, [pscustomobject]$PythonInfo)
    if (-not $ProjectRoot -or -not $PythonInfo.Exe) { return $false }
    $appDir = Join-Path $ProjectRoot 'desktop_app'
    $appPy = Join-Path $appDir 'app.py'
    if (-not (Test-Path -LiteralPath $appPy)) { return $false }
    $exe = if ($PythonInfo.PythonW) { $PythonInfo.PythonW } else { $PythonInfo.Exe }
    $args = New-Object System.Collections.Generic.List[string]
    foreach ($p in $PythonInfo.Prefix) { [void]$args.Add($p) }
    [void]$args.Add(('"' + $appPy + '"'))
    try {
        Start-Process -FilePath $exe -ArgumentList ($args.ToArray()) -WorkingDirectory $appDir | Out-Null
        Add-ReportLine $script:RepairFile "Started Focus Studio from: $appPy"
        Start-Sleep -Seconds 10
        return $true
    } catch {
        Add-ReportLine $script:RepairFile "Could not start Focus Studio: $($_.Exception.Message)"
        return $false
    }
}

function Repair-AppListener {
    param([string]$ProjectRoot, [pscustomobject]$PythonInfo, [int]$CameraPort, [string]$SourceVersion)
    if (-not $ProjectRoot) { return }
    $health = Invoke-HttpCheck -Url "http://127.0.0.1:$CameraPort/api/health" -NoProxy
    $runningVersion = ''
    if ($health.Body) {
        try { $runningVersion = (($health.Body | ConvertFrom-Json).version) } catch {}
    }
    $owners = @(Get-PortOwners -Ports @($CameraPort))
    $needsRestart = ($health.Status -ne 200) -or ($SourceVersion -and $runningVersion -and $SourceVersion -ne $runningVersion)
    if (-not $needsRestart) { return }

    Add-ReportLine $script:RepairFile "Camera listener needs attention. HTTP=$($health.Status), source=$SourceVersion, running=$runningVersion"
    if ($owners.Count -gt 0) {
        $ownerText = ($owners | Format-List | Out-String -Width 240)
        Add-ReportLine $script:RepairFile $ownerText
        Write-Host ''
        Write-Host "Port $CameraPort is owned by PID(s): $($owners.PID -join ', ')." -ForegroundColor Yellow
        Write-Host 'Stopping it may close an older Focus Studio instance. Timer state is normally restorable.'
        $answer = Read-Host 'Stop the current camera/app process and launch this project copy? [y/N]'
        if ($answer -match '^(?i)y(?:es)?$') {
            foreach ($pidValue in ($owners.PID | Select-Object -Unique)) {
                try { Stop-Process -Id $pidValue -Force -ErrorAction Stop; Add-ReportLine $script:RepairFile "Stopped PID $pidValue" } catch { Add-ReportLine $script:RepairFile "Could not stop PID $pidValue: $($_.Exception.Message)" }
            }
            Start-Sleep -Seconds 3
            [void](Start-CorrectFocusStudio -ProjectRoot $ProjectRoot -PythonInfo $PythonInfo)
        }
    } else {
        $config = Get-ConfigObject $ProjectRoot
        if ($config -and $config.remote_camera_enabled) {
            Write-Host ''
            $answer = Read-Host 'The local camera server is not running. Start Focus Studio now? [Y/n]'
            if (-not $answer -or $answer -match '^(?i)y(?:es)?$') {
                [void](Start-CorrectFocusStudio -ProjectRoot $ProjectRoot -PythonInfo $PythonInfo)
            }
        }
    }
}

function Do-SafeRepairs {
    param([string]$ProjectRoot, [pscustomobject]$PythonInfo, [string]$CloudflaredPath, [int]$CameraPort, [string]$SourceVersion)
    Add-Section $script:RepairFile 'SAFE REPAIRS'
    Add-ReportLine $script:RepairFile 'No Winsock reset, adapter reset, proxy reset, v2rayN reset, or Tailscale reset is performed.'

    try { ipconfig.exe /flushdns 2>&1 | ForEach-Object { Add-ReportLine $script:RepairFile $_ } } catch {}
    try { w32tm.exe /resync 2>&1 | ForEach-Object { Add-ReportLine $script:RepairFile $_ } } catch {}

    if ($ProjectRoot) {
        try {
            Get-ChildItem -LiteralPath $ProjectRoot -File -Recurse -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
            Add-ReportLine $script:RepairFile 'Unblocked downloaded project files.'
        } catch { Add-ReportLine $script:RepairFile "Unblock failed: $($_.Exception.Message)" }
    }

    if ($CloudflaredPath) { Ensure-FirewallRule -Name 'Mojjss Focus Studio - Cloudflared outbound' -Program $CloudflaredPath }
    if ($PythonInfo.Exe) { Ensure-FirewallRule -Name 'Mojjss Focus Studio - Python outbound' -Program $PythonInfo.Exe }

    try {
        $svc = Get-Service -Name Cloudflared -ErrorAction Stop
        & sc.exe config Cloudflared start= delayed-auto 2>&1 | ForEach-Object { Add-ReportLine $script:RepairFile $_ }
        & sc.exe failure Cloudflared reset= 86400 actions= restart/5000/restart/15000/restart/60000 2>&1 | ForEach-Object { Add-ReportLine $script:RepairFile $_ }
        Restart-Service -Name Cloudflared -Force -ErrorAction Stop
        Add-ReportLine $script:RepairFile 'Restarted Cloudflared service and configured automatic recovery.'
        Start-Sleep -Seconds 12
    } catch {
        Add-ReportLine $script:RepairFile "Cloudflared service restart skipped/failed: $($_.Exception.Message)"
    }

    Repair-AppListener -ProjectRoot $ProjectRoot -PythonInfo $PythonInfo -CameraPort $CameraPort -SourceVersion $SourceVersion
}

function Set-CloudflaredHttp2IPv4 {
    try {
        $regPath = 'HKLM:\SYSTEM\CurrentControlSet\Services\Cloudflared'
        $imagePath = (Get-ItemProperty -LiteralPath $regPath -Name ImagePath -ErrorAction Stop).ImagePath
        $updated = $imagePath
        $updated = [regex]::Replace($updated, '(?i)\s+--protocol\s+\S+', '')
        $updated = [regex]::Replace($updated, '(?i)\s+--edge-ip-version\s+\S+', '')
        if ($updated -match '(?i)\btunnel\b') {
            $updated = ([regex]::new('(?i)\btunnel\b')).Replace($updated, 'tunnel --protocol http2 --edge-ip-version 4', 1)
        } else {
            throw 'The service ImagePath does not contain the tunnel command.'
        }
        Set-ItemProperty -LiteralPath $regPath -Name ImagePath -Value $updated -ErrorAction Stop
        Add-ReportLine $script:RepairFile 'Configured Cloudflared service to use HTTP/2 and IPv4. Token omitted from report.'
        Restart-Service Cloudflared -Force -ErrorAction Stop
        Start-Sleep -Seconds 20
        return $true
    } catch {
        Add-ReportLine $script:RepairFile "Could not apply HTTP/2 IPv4 fallback: $($_.Exception.Message)"
        return $false
    }
}

function Repair-CloudflaredWithToken {
    param([string]$CloudflaredPath, [string]$CameraUrl)
    Add-Section $script:RepairFile 'CLOUDFLARED TOKEN SERVICE REPAIR'
    if (-not $CloudflaredPath) {
        Add-ReportLine $script:RepairFile 'cloudflared.exe was not found. Install Cloudflare Tunnel first, then rerun this tool.'
        Add-Summary 'FAIL' 'cloudflared.exe is missing; token-based service repair could not run.'
        return $false
    }

    Write-Host ''
    Write-Host 'PRIVATE SECRET REQUIRED' -ForegroundColor Yellow
    Write-Host 'In Cloudflare: Networking -> Tunnels -> mojjss-focus-camera -> Add a replica -> Windows.'
    Write-Host 'Copy only the long eyJ... tunnel token. It will be hidden and will never be written to the report.'
    $secureToken = Read-Host 'Paste the private Cloudflare tunnel token' -AsSecureString
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureToken)
    $token = ''
    try { $token = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
    if (-not $token -or $token -notmatch '^eyJ[A-Za-z0-9._~-]{20,}$') {
        Add-ReportLine $script:RepairFile 'The entered value did not look like a Cloudflare tunnel token. Repair cancelled.'
        Add-Summary 'FAIL' 'Tunnel service repair was cancelled because the token format was invalid.'
        $token = $null
        return $false
    }

    try {
        Stop-Service Cloudflared -Force -ErrorAction SilentlyContinue
        & $CloudflaredPath service uninstall 2>&1 | ForEach-Object { Add-ReportLine $script:RepairFile $_ }
        Start-Sleep -Seconds 3
        if (Get-Service Cloudflared -ErrorAction SilentlyContinue) {
            & sc.exe delete Cloudflared 2>&1 | ForEach-Object { Add-ReportLine $script:RepairFile $_ }
            Start-Sleep -Seconds 3
        }

        $installOutput = & $CloudflaredPath service install $token 2>&1 | Out-String
        Add-ReportLine $script:RepairFile $installOutput
        & sc.exe config Cloudflared start= delayed-auto 2>&1 | ForEach-Object { Add-ReportLine $script:RepairFile $_ }
        & sc.exe failure Cloudflared reset= 86400 actions= restart/5000/restart/15000/restart/60000 2>&1 | ForEach-Object { Add-ReportLine $script:RepairFile $_ }
        Start-Service Cloudflared -ErrorAction Stop
        Add-ReportLine $script:RepairFile 'Installed and started Cloudflared service with the privately entered token.'
        Start-Sleep -Seconds 22
    } catch {
        Add-ReportLine $script:RepairFile "Token service installation failed: $($_.Exception.Message)"
        Add-Summary 'FAIL' 'Cloudflared service installation failed. See 09_REPAIR_LOG.txt.'
        $token = $null
        return $false
    }

    $public = if ($CameraUrl) { Invoke-HttpCheck -Url ($CameraUrl.TrimEnd('/') + '/api/health') } else { $null }
    if ($public -and $public.Status -eq 200) {
        Add-ReportLine $script:RepairFile 'Public camera health passed after the normal service installation.'
        Add-Summary 'PASS' 'Cloudflared reconnected and the public camera health endpoint returned HTTP 200.'
        $token = $null
        return $true
    }

    Add-ReportLine $script:RepairFile 'The normal service did not make the public camera healthy. Trying HTTP/2 + IPv4 fallback.'
    [void](Set-CloudflaredHttp2IPv4)
    $public2 = if ($CameraUrl) { Invoke-HttpCheck -Url ($CameraUrl.TrimEnd('/') + '/api/health') } else { $null }
    if ($public2 -and $public2.Status -eq 200) {
        Add-Summary 'PASS' 'Cloudflared connected after applying the HTTP/2 + IPv4 fallback.'
        $token = $null
        return $true
    }

    if ($public2) { Add-ReportLine $script:RepairFile (Format-HttpResult $public2) } else { Add-ReportLine $script:RepairFile 'No camera URL was configured.' }
    Add-Summary 'FAIL' 'Cloudflared was reinstalled but the public camera is still unavailable. The report contains connector/network diagnostics.'
    $token = $null
    return $false
}

function Run-CloudflaredDiag {
    param([string]$CloudflaredPath, [string]$WorkingDirectory, [string]$OutputFile)
    if (-not $CloudflaredPath) { Add-ReportLine $OutputFile 'cloudflared.exe not found.'; return }
    Add-Section $OutputFile 'cloudflared tunnel diag (maximum 60 seconds)'
    $diagWork = Join-Path $WorkingDirectory '_cloudflared_diag_private_temp'
    Remove-Item -LiteralPath $diagWork -Recurse -Force -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Path $diagWork -Force | Out-Null
    $stdout = Join-Path $diagWork 'cloudflared_diag_stdout.tmp'
    $stderr = Join-Path $diagWork 'cloudflared_diag_stderr.tmp'
    try {
        $p = Start-Process -FilePath $CloudflaredPath -ArgumentList @('tunnel','diag') -WorkingDirectory $diagWork -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru -WindowStyle Hidden
        if (-not $p.WaitForExit(60000)) {
            try { $p.Kill() } catch {}
            Add-ReportLine $OutputFile 'cloudflared tunnel diag timed out after 60 seconds and was stopped.'
        } else {
            Add-ReportLine $OutputFile "Exit code: $($p.ExitCode)"
        }
        if (Test-Path $stdout) { Add-ReportLine $OutputFile (Get-Content $stdout -Raw) }
        if (Test-Path $stderr) { Add-ReportLine $OutputFile (Get-Content $stderr -Raw) }
    } catch {
        Add-ReportLine $OutputFile "cloudflared tunnel diag failed: $($_.Exception.Message)"
    } finally {
        try {
            $generated = Get-ChildItem -LiteralPath $diagWork -File -ErrorAction SilentlyContinue | Select-Object Name,Length
            if ($generated) {
                Add-ReportLine $OutputFile 'Private diagnostic artifacts created and deleted after recording their names/sizes:'
                Add-ReportLine $OutputFile ($generated | Format-Table -AutoSize | Out-String)
            }
        } catch {}
        Remove-Item -LiteralPath $diagWork -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Collect-AllDiagnostics {
    param(
        [string]$ProjectRoot,
        [pscustomobject]$PythonInfo,
        [string]$CloudflaredPath,
        [object]$Config,
        [string]$SourceVersion,
        [int]$CameraPort,
        [int]$MonitorPort,
        [string]$CameraUrl,
        [string]$DashboardUrl
    )
    Write-Host ''
    Write-Host 'Collecting full diagnostics...' -ForegroundColor Cyan

    Capture-Block $script:SystemFile 'SYSTEM AND WINDOWS' {
        Get-ComputerInfo | Select-Object WindowsProductName,WindowsVersion,OsBuildNumber,OsArchitecture,CsName,CsManufacturer,CsModel,CsTotalPhysicalMemory,OsLastBootUpTime,TimeZone
        whoami.exe /all
        Get-Date -Format o
        Get-TimeZone
    }

    Capture-Block $script:SystemFile 'NETWORK ADAPTERS AND ADDRESSES' {
        Get-NetAdapter | Sort-Object Status,Name | Format-Table -AutoSize Name,InterfaceDescription,Status,LinkSpeed,MacAddress,ifIndex
        Get-NetIPConfiguration | Format-List
        ipconfig.exe /all
        route.exe print
    }

    Capture-Block $script:SystemFile 'DNS, PROXY, V2RAYN, TAILSCALE' {
        Get-DnsClientServerAddress | Format-Table -AutoSize
        netsh.exe winhttp show proxy
        $proxy = Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -ErrorAction SilentlyContinue
        [pscustomobject]@{ ProxyEnable=$proxy.ProxyEnable; ProxyServer=$proxy.ProxyServer; AutoConfigURL=$proxy.AutoConfigURL; ProxyOverride=$proxy.ProxyOverride } | Format-List
        Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'v2rayN|xray|sing-box|mihomo|tailscale|cloudflared' } | Select-Object ProcessId,Name,ExecutablePath,@{n='CommandLine';e={Protect-Text $_.CommandLine}} | Format-List
        Get-Service | Where-Object { $_.Name -match 'Cloudflared|Tailscale|Dnscache|WinHttpAutoProxySvc' } | Format-Table -AutoSize Name,Status,StartType
    }

    Capture-Block $script:SystemFile 'FIREWALL AND SECURITY' {
        Get-NetFirewallProfile | Format-List Name,Enabled,DefaultInboundAction,DefaultOutboundAction
        Get-NetFirewallRule | Where-Object { $_.DisplayName -match 'cloudflared|Focus Studio|Python|v2ray|Tailscale' } | Select-Object DisplayName,Enabled,Direction,Action,Profile | Format-Table -AutoSize
        Get-CimInstance -Namespace root\SecurityCenter2 -ClassName AntivirusProduct -ErrorAction SilentlyContinue | Select-Object displayName,pathToSignedProductExe,productState | Format-List
    }

    Capture-Block $script:ProjectFile 'PROJECT LOCATION AND FILES' {
        "Project root: $ProjectRoot"
        "Source version: $SourceVersion"
        if ($ProjectRoot) {
            Get-ChildItem -LiteralPath $ProjectRoot -Force | Select-Object Mode,LastWriteTime,Length,Name | Format-Table -AutoSize
            Get-ChildItem -LiteralPath (Join-Path $ProjectRoot 'desktop_app') -File | Select-Object LastWriteTime,Length,Name | Sort-Object Name | Format-Table -AutoSize
            foreach ($name in @('desktop_app\app.py','desktop_app\tailscale_camera.py','desktop_app\version.py','desktop_app\verify_camera_stack.py','cloudflare_dashboard\public\index.html','cloudflare_dashboard\functions\api\health.js')) {
                $p = Join-Path $ProjectRoot $name
                if (Test-Path $p) { Get-FileHash -Algorithm SHA256 -LiteralPath $p | Select-Object Path,Hash }
            }
        }
    }

    Capture-Block $script:ProjectFile 'SAFE CONFIGURATION SUMMARY (SECRETS OMITTED)' {
        if ($ProjectRoot) { Get-ConfigSummary (Join-Path $ProjectRoot 'desktop_app\config.json') } else { 'Project not found.' }
    }

    Capture-Block $script:ProjectFile 'CONFIG/DATA FILE VALIDATION' {
        if (-not $ProjectRoot) { 'Project not found.'; return }
        $appDir = Join-Path $ProjectRoot 'desktop_app'
        foreach ($jsonName in @('config.json','timer_state.json')) {
            $p = Join-Path $appDir $jsonName
            if (Test-Path $p) {
                try { $null = Get-Content $p -Raw | ConvertFrom-Json; "$jsonName : valid JSON" } catch { "$jsonName : INVALID JSON: $($_.Exception.Message)" }
            } else { "$jsonName : not present" }
        }
        $schedule = Join-Path $appDir 'schedule.csv'
        if (Test-Path $schedule) {
            try { $rows = @(Import-Csv $schedule); "schedule.csv : valid CSV, rows=$($rows.Count)" } catch { "schedule.csv : invalid: $($_.Exception.Message)" }
        } else { 'schedule.csv : not present' }
    }

    Capture-Block $script:PythonFile 'PYTHON AND DEPENDENCIES' {
        "Python executable: $($PythonInfo.Exe)"
        "Python prefix arguments: $($PythonInfo.Prefix -join ' ')"
        if ($PythonInfo.Exe) {
            Invoke-Python $PythonInfo @('--version')
            Invoke-Python $PythonInfo @('-m','pip','--version')
            Invoke-Python $PythonInfo @('-m','pip','check')
            Invoke-Python $PythonInfo @('-c','import customtkinter, matplotlib, requests, PIL, cv2; print("Core imports: PASS")')
        } else { 'Python was not found.' }
    }

    Capture-Block $script:PythonFile 'PYTHON SOURCE COMPILE CHECK' {
        if ($ProjectRoot -and $PythonInfo.Exe) {
            Invoke-Python $PythonInfo @('-m','compileall','-q',(Join-Path $ProjectRoot 'desktop_app'))
            if ($LASTEXITCODE -eq 0) { 'compileall: PASS' } else { "compileall: FAIL, exit=$LASTEXITCODE" }
        } else { 'Skipped.' }
    }

    Capture-Block $script:PythonFile 'SQLITE DATABASE INTEGRITY' {
        if ($ProjectRoot -and $PythonInfo.Exe) {
            $db = Join-Path $ProjectRoot 'desktop_app\focus_history.db'
            if (Test-Path $db) {
                $code = 'import sqlite3,sys; p=sys.argv[1]; con=sqlite3.connect("file:"+p+"?mode=ro", uri=True); print("integrity_check:", con.execute("PRAGMA integrity_check").fetchone()[0]); print("tables:", [r[0] for r in con.execute("select name from sqlite_master where type=\"table\" order by name")]); con.close()'
                Invoke-Python $PythonInfo @('-c',$code,$db)
            } else { 'focus_history.db does not exist yet.' }
        } else { 'Skipped.' }
    }

    Capture-Block $script:AppFile 'FOCUS STUDIO AND CAMERA PROCESSES' {
        Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^pythonw?\.exe$|Focus|cloudflared' } | Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,@{n='CommandLine';e={Protect-Text $_.CommandLine}},CreationDate | Format-List
        Get-PortOwners -Ports @($CameraPort,$MonitorPort) | Format-List
    }

    Capture-Block $script:AppFile 'LOCAL CAMERA HEALTH' {
        Format-HttpResult (Invoke-HttpCheck -Url "http://127.0.0.1:$CameraPort/api/health" -NoProxy)
    }
    Capture-Block $script:AppFile 'LOCAL CAMERA STATUS (NO PASSWORD)' {
        Format-HttpResult (Invoke-HttpCheck -Url "http://127.0.0.1:$CameraPort/api/status" -NoProxy)
    }
    Capture-Block $script:AppFile 'LOCAL MONITOR HEALTH' {
        Format-HttpResult (Invoke-HttpCheck -Url "http://127.0.0.1:$MonitorPort/api/health" -NoProxy)
    }
    Capture-Block $script:AppFile 'LOCAL MONITOR STATUS' {
        Format-HttpResult (Invoke-HttpCheck -Url "http://127.0.0.1:$MonitorPort/api/status" -NoProxy)
    }

    if ($ProjectRoot -and $PythonInfo.Exe -and (Test-Path (Join-Path $ProjectRoot 'desktop_app\verify_camera_stack.py'))) {
        Capture-Block $script:AppFile 'BUILT-IN verify_camera_stack.py' {
            Push-Location (Join-Path $ProjectRoot 'desktop_app')
            try { 'n' | Invoke-Python $PythonInfo @('verify_camera_stack.py') } finally { Pop-Location }
        }
    }

    Capture-Block $script:CloudflaredFile 'CLOUDFLARED EXECUTABLE AND VERSION' {
        "cloudflared path: $CloudflaredPath"
        if ($CloudflaredPath) { & $CloudflaredPath --version }
        Get-Command cloudflared.exe -ErrorAction SilentlyContinue | Format-List Source,Version
    }

    Capture-Block $script:CloudflaredFile 'CLOUDFLARED WINDOWS SERVICE' {
        Get-Service Cloudflared -ErrorAction SilentlyContinue | Format-List Name,Status,StartType
        & sc.exe queryex Cloudflared
        & sc.exe qc Cloudflared
        $svc = Get-CimInstance Win32_Service -Filter "Name='Cloudflared'" -ErrorAction SilentlyContinue
        if ($svc) { $svc | Select-Object Name,State,StartMode,ProcessId,StartName,@{n='PathName';e={Protect-Text $_.PathName}} | Format-List }
        $reg = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\Cloudflared' -ErrorAction SilentlyContinue
        if ($reg) { [pscustomobject]@{ ImagePath=(Protect-Text $reg.ImagePath); Start=$reg.Start; ObjectName=$reg.ObjectName } | Format-List }
        Get-CimInstance Win32_Process | Where-Object Name -eq 'cloudflared.exe' | Select-Object ProcessId,ExecutablePath,@{n='CommandLine';e={Protect-Text $_.CommandLine}},CreationDate | Format-List
    }

    Capture-Block $script:CloudflaredFile 'CLOUDFLARED DNS AND PORT 7844' {
        Resolve-DnsName region1.v2.argotunnel.com -ErrorAction Continue
        Resolve-DnsName region2.v2.argotunnel.com -ErrorAction Continue
        Resolve-DnsName -Type SRV _v2-origintunneld._tcp.argotunnel.com -ErrorAction Continue
        Test-NetConnection region1.v2.argotunnel.com -Port 7844 -InformationLevel Detailed
        Test-NetConnection region2.v2.argotunnel.com -Port 7844 -InformationLevel Detailed
    }
    Run-CloudflaredDiag -CloudflaredPath $CloudflaredPath -WorkingDirectory $script:ReportDir -OutputFile $script:CloudflaredFile

    Capture-Block $script:CloudFile 'PUBLIC DNS' {
        foreach ($url in @($CameraUrl,$DashboardUrl)) {
            if ($url) {
                $hostName = ([uri]$url).Host
                "--- $hostName ---"
                Resolve-DnsName $hostName -ErrorAction Continue
                Resolve-DnsName -Type CNAME $hostName -ErrorAction Continue
                nslookup.exe -type=CNAME $hostName
                Test-NetConnection $hostName -Port 443 -InformationLevel Detailed
            }
        }
    }

    if ($CameraUrl) {
        Capture-Block $script:CloudFile 'PUBLIC CAMERA HEALTH - NORMAL USER NETWORK/PROXY' {
            Format-HttpResult (Invoke-HttpCheck -Url ($CameraUrl.TrimEnd('/') + '/api/health'))
        }
        Capture-Block $script:CloudFile 'PUBLIC CAMERA HEALTH - DIRECT, NO USER PROXY' {
            Format-HttpResult (Invoke-HttpCheck -Url ($CameraUrl.TrimEnd('/') + '/api/health') -NoProxy)
        }
        $origin = if ($Config -and $Config.tailscale_camera_allowed_origin) { ([string]$Config.tailscale_camera_allowed_origin).Split(',')[0].Trim().TrimEnd('/') } elseif ($DashboardUrl) { $DashboardUrl.TrimEnd('/') } else { '' }
        if ($origin) {
            Capture-Block $script:CloudFile 'PUBLIC CAMERA CORS PREFLIGHT' {
                $headers = @{ Origin=$origin; 'Access-Control-Request-Method'='POST'; 'Access-Control-Request-Headers'='x-camera-password' }
                Format-HttpResult (Invoke-HttpCheck -Url ($CameraUrl.TrimEnd('/') + '/api/unlock') -Method OPTIONS -Headers $headers)
            }
        }
    }

    if ($DashboardUrl) {
        Capture-Block $script:CloudFile 'CLOUD DASHBOARD WEBSITE' {
            Format-HttpResult (Invoke-HttpCheck -Url ($DashboardUrl.TrimEnd('/') + '/')) 2500
        }
        Capture-Block $script:CloudFile 'CLOUD DASHBOARD API HEALTH' {
            Format-HttpResult (Invoke-HttpCheck -Url ($DashboardUrl.TrimEnd('/') + '/api/health'))
        }
        Capture-Block $script:CloudFile 'CLOUD DASHBOARD STATUS WITHOUT KEY (401/403 CAN BE EXPECTED)' {
            Format-HttpResult (Invoke-HttpCheck -Url ($DashboardUrl.TrimEnd('/') + '/api/status'))
        }
    }

    Capture-Block $script:CloudFile 'EXPECTED CLOUDFLARE CONFIGURATION' {
        "Published application route must be:"
        "  $CameraUrl  ->  http://127.0.0.1:$CameraPort"
        'The origin must not point back to the public camera hostname.'
        'Expected tunnel: mojjss-focus-camera; healthy connector/replica count must be at least 1.'
        'The Cloudflare Pages/D1 dashboard and the private-camera Tunnel are separate services.'
    }

    Capture-Block $script:EventsFile 'RECENT SERVICE CONTROL MANAGER EVENTS' {
        Get-WinEvent -FilterHashtable @{LogName='System'; StartTime=(Get-Date).AddDays(-5)} -ErrorAction SilentlyContinue |
            Where-Object { $_.ProviderName -eq 'Service Control Manager' -and $_.Message -match 'cloudflared|Python|Focus' } |
            Select-Object -First 150 TimeCreated,Id,LevelDisplayName,ProviderName,Message | Format-List
    }
    Capture-Block $script:EventsFile 'RECENT NETWORK/DNS EVENTS' {
        Get-WinEvent -FilterHashtable @{LogName='System'; StartTime=(Get-Date).AddDays(-3)} -ErrorAction SilentlyContinue |
            Where-Object { $_.ProviderName -match 'DNS|Tcpip|Schannel' } |
            Select-Object -First 150 TimeCreated,Id,LevelDisplayName,ProviderName,Message | Format-List
    }
    Capture-Block $script:EventsFile 'RECENT APPLICATION ERRORS FOR PYTHON/CLOUDFLARED' {
        Get-WinEvent -FilterHashtable @{LogName='Application'; StartTime=(Get-Date).AddDays(-5)} -ErrorAction SilentlyContinue |
            Where-Object { $_.Message -match 'cloudflared|python|mojjss|Focus Studio' } |
            Select-Object -First 150 TimeCreated,Id,LevelDisplayName,ProviderName,Message | Format-List
    }

    Capture-Block $script:GitFile 'GIT REPOSITORY STATUS' {
        if ($ProjectRoot -and (Get-Command git.exe -ErrorAction SilentlyContinue)) {
            Push-Location $ProjectRoot
            try {
                git.exe rev-parse --show-toplevel
                git.exe log -1 --date=iso --pretty=fuller
                git.exe status --short --branch
                git.exe remote -v
                git.exe diff --stat
            } finally { Pop-Location }
        } else { 'Git or project folder not found.' }
    }

    Capture-Block $script:GitFile 'GITHUB REPOSITORY REACHABILITY' {
        Format-HttpResult (Invoke-HttpCheck -Url 'https://github.com/mojjss/mojjss_focus_studio') 1200
    }

    $localHealth = Invoke-HttpCheck -Url "http://127.0.0.1:$CameraPort/api/health" -NoProxy
    if ($localHealth.Status -eq 200) { Add-Summary 'PASS' "Local camera API is healthy on 127.0.0.1:$CameraPort." } else { Add-Summary 'FAIL' "Local camera API is not healthy on 127.0.0.1:$CameraPort (HTTP $($localHealth.Status))." }

    if ($CameraUrl) {
        $publicHealth = Invoke-HttpCheck -Url ($CameraUrl.TrimEnd('/') + '/api/health')
        if ($publicHealth.Status -eq 200) { Add-Summary 'PASS' 'Public camera endpoint is healthy.' }
        elseif ($publicHealth.Status -eq 530 -or $publicHealth.Body -match '1033|Argo Tunnel error|cloudflared') { Add-Summary 'FAIL' "Public camera is unavailable because the Cloudflare Tunnel connector/route is unhealthy (HTTP $($publicHealth.Status))." }
        else { Add-Summary 'FAIL' "Public camera endpoint failed with HTTP $($publicHealth.Status)." }
    }

    try {
        $svc = Get-Service Cloudflared -ErrorAction Stop
        if ($svc.Status -eq 'Running') { Add-Summary 'PASS' 'Cloudflared Windows service reports Running.' } else { Add-Summary 'FAIL' "Cloudflared service status is $($svc.Status)." }
    } catch { Add-Summary 'FAIL' 'Cloudflared Windows service is missing.' }

    if ($CloudflaredPath) { Add-Summary 'PASS' "cloudflared.exe found at $CloudflaredPath." } else { Add-Summary 'FAIL' 'cloudflared.exe was not found.' }
    if ($ProjectRoot) { Add-Summary 'PASS' "Focus Studio project found at $ProjectRoot." } else { Add-Summary 'WARN' 'Focus Studio project folder was not found; project-specific checks were skipped.' }
    if ($SourceVersion) { Add-Summary 'INFO' "Detected Focus Studio source version: $SourceVersion." }
}

function Finalize-Report {
    Add-Section $script:SummaryFile 'WHAT TO UPLOAD'
    Add-ReportLine $script:SummaryFile 'Upload the generated ZIP to ChatGPT. Do not upload config.json or a raw cloudflared command containing the eyJ... token.'
    Add-ReportLine $script:SummaryFile 'The ZIP has been passed through an automatic token/password/key redaction step, but review it before sharing publicly.'

    $notice = @"
This report was generated for mojjss Focus Studio.
Automatic redaction removes Cloudflare tunnel tokens beginning with eyJ, URL token/key/password values, Authorization credentials, and common secret fields.
The report intentionally does not copy config.json, database contents, camera images, passwords, dashboard keys, Pixela tokens, or tunnel credentials.
Computer name, Windows username, local paths, IP addresses, installed software, and process names may still appear because they are useful for diagnosis.
"@
    Set-Content -LiteralPath (Join-Path $script:ReportDir '10_REDACTION_AND_PRIVACY.txt') -Value $notice -Encoding UTF8

    foreach ($file in (Get-ChildItem -LiteralPath $script:ReportDir -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -in @('.txt','.log','.json') })) {
        try {
            $raw = Get-Content -LiteralPath $file.FullName -Raw -ErrorAction Stop
            Set-Content -LiteralPath $file.FullName -Value (Protect-Text $raw) -Encoding UTF8
        } catch {}
    }

    $zipPath = "$($script:ReportDir).zip"
    Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue
    try {
        Compress-Archive -Path (Join-Path $script:ReportDir '*') -DestinationPath $zipPath -CompressionLevel Optimal -Force
        Write-Host ''
        Write-Host 'DONE' -ForegroundColor Green
        Write-Host "Report folder: $($script:ReportDir)"
        Write-Host "UPLOAD THIS ZIP: $zipPath" -ForegroundColor Cyan
        try { Start-Process explorer.exe -ArgumentList "/select,`"$zipPath`"" | Out-Null } catch {}
    } catch {
        Write-Host "Could not create ZIP: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "Report folder: $($script:ReportDir)"
    }
}

Clear-Host
Write-Host 'Mojjss Focus Studio - Full Fix and Diagnostics' -ForegroundColor Cyan
Write-Host 'Targets: desktop app, camera server, Cloudflare Tunnel, Pages/D1 dashboard, Python, ports, DNS and Windows service.'
Write-Host ''
Write-Host '[1] Full diagnostics only (no changes)'
Write-Host '[2] Safe repairs + full diagnostics'
Write-Host '[3] Fix Cloudflare error 1033 with private tunnel token + safe repairs + full diagnostics'
Write-Host '[4] Exit'
$choice = Read-Host 'Choose 1, 2, 3, or 4'
if ($choice -eq '4') { exit 0 }
if ($choice -notin @('1','2','3')) { $choice = '1' }

$desktop = [Environment]::GetFolderPath('Desktop')
if (-not $desktop) { $desktop = $env:USERPROFILE }
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$script:ReportDir = Join-Path $desktop "FOCUS_STUDIO_FULL_REPORT_$stamp"
New-Item -ItemType Directory -Path $script:ReportDir -Force | Out-Null
$script:SummaryFile = Join-Path $script:ReportDir '00_SUMMARY.txt'
$script:SystemFile = Join-Path $script:ReportDir '01_SYSTEM_NETWORK.txt'
$script:ProjectFile = Join-Path $script:ReportDir '02_PROJECT_CONFIG.txt'
$script:AppFile = Join-Path $script:ReportDir '03_APP_CAMERA.txt'
$script:CloudflaredFile = Join-Path $script:ReportDir '04_CLOUDFLARED_TUNNEL.txt'
$script:CloudFile = Join-Path $script:ReportDir '05_CLOUD_ENDPOINTS_PAGES_D1.txt'
$script:EventsFile = Join-Path $script:ReportDir '06_WINDOWS_EVENTS.txt'
$script:PythonFile = Join-Path $script:ReportDir '07_PYTHON_DATABASE.txt'
$script:GitFile = Join-Path $script:ReportDir '08_GIT_GITHUB.txt'
$script:RepairFile = Join-Path $script:ReportDir '09_REPAIR_LOG.txt'

Set-Content -LiteralPath $script:SummaryFile -Value "Mojjss Focus Studio full report`r`nCreated: $(Get-Date -Format o)`r`nMode: $choice`r`n" -Encoding UTF8
Set-Content -LiteralPath $script:RepairFile -Value "Repair log`r`nMode: $choice`r`n" -Encoding UTF8

$projectRoot = Find-ProjectRoot
$pythonInfo = Get-PythonInfo $projectRoot
$cloudflaredPath = Get-CloudflaredPath
$config = Get-ConfigObject $projectRoot
$sourceVersion = Get-SourceVersion $projectRoot
$cameraPort = 8788
$monitorPort = 8765
$cameraUrl = 'https://camera.mojjss.ir'
$dashboardUrl = 'https://timer.mojjss.ir'
if ($config) {
    if ($config.tailscale_camera_port) { $cameraPort = [int]$config.tailscale_camera_port }
    if ($config.monitor_port) { $monitorPort = [int]$config.monitor_port }
    if ($config.tailscale_camera_url) { $cameraUrl = ([string]$config.tailscale_camera_url).Trim().TrimEnd('/') }
    if ($config.cloud_dashboard_url) { $dashboardUrl = ([string]$config.cloud_dashboard_url).Trim().TrimEnd('/') }
}

Add-Summary 'INFO' "Mode selected: $choice"
Add-Summary 'INFO' "Camera URL: $cameraUrl"
Add-Summary 'INFO' "Dashboard URL: $dashboardUrl"
Add-Summary 'INFO' 'v2rayN, Tailscale, Windows proxy, Winsock, and network adapters will not be reset.'

if ($choice -in @('2','3')) {
    Do-SafeRepairs -ProjectRoot $projectRoot -PythonInfo $pythonInfo -CloudflaredPath $cloudflaredPath -CameraPort $cameraPort -SourceVersion $sourceVersion
}
if ($choice -eq '3') {
    [void](Repair-CloudflaredWithToken -CloudflaredPath $cloudflaredPath -CameraUrl $cameraUrl)
}

Collect-AllDiagnostics -ProjectRoot $projectRoot -PythonInfo $pythonInfo -CloudflaredPath $cloudflaredPath -Config $config -SourceVersion $sourceVersion -CameraPort $cameraPort -MonitorPort $monitorPort -CameraUrl $cameraUrl -DashboardUrl $dashboardUrl
Finalize-Report
exit 0
